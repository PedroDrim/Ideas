
# This is the server logic for a Shiny web application.
# You can find out more about building applications with Shiny here:
#
# http://shiny.rstudio.com
#

library(shiny)
source("startFunction.R")

shinyServer(function(input, output, session) {
     
     load.datas()
     
     set_data = function(){
          
          arquivo = "output//dadosBolsa.csv"
          keys = c("YHOO","AAPL","MSFT","GOOG","BIDU","FB","IBM","TWTR","HPQ")
          
          persisteceObject = PersistenceClass$new(arquivo)
          requestObject = RequestClass$new()
          
          exist = file.exists(arquivo)
          
          values = requestObject$getValues.now(keys)
          persisteceObject$serializeTable(values, !exist)
     }
     
     output$graph <- renderPlot({
          
          graphObject = GraphClass$new()   
       
          invalidateLater(1000, session)
          set_data()
          
          tabela.ini = fread("output//dadosBolsa.csv")
          coln = input$colNames
          rangemax = input$rangeMax
          
          graphObject$getPlot(tabela.ini, coln, rangemax)
     })
     
})
