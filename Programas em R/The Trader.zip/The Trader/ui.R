
# This is the user-interface definition of a Shiny web application.
# You can find out more about building applications with Shiny here:
#
# http://shiny.rstudio.com
#

library(shiny)

# pesquisar a variavel LastTradeRealtimeWithTime para identificar o estado da bolsa (aberta / fechada)
# https://query.yahooapis.com/v1/public/yql?q=select%20*%20from%20yahoo.finance.quotes%20where%20symbol%20in%20(%27AAPL%27)&format=json&env=store%3A%2F%2Fdatatables.org%2Falltableswithkeys&callback=

shinyUI(fluidPage(
     
     # Application title
     titlePanel("The Trader Shiny aplication"),
     
     sliderInput("rangeMax", label = h3("Tamanho Maximo de exibicao"), min = 10, 
                 max = 100, value = 50),
     
     radioButtons("colNames", label = h3("Variavel em exibicao"),
                  choices = list("Maximo preco de compra" = "Bid", "Minimo preco de venda" = "Ask", "Preco da acao" = "LastTradePriceOnly"), 
                  selected = "LastTradePriceOnly"),
     
     # Show a plot of the generated distribution
     mainPanel(
          plotOutput("graph")
     )
)
)
