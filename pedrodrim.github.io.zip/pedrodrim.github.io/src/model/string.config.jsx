export default {

    DRIM: "PedroDrim",
    sobre: "Sobre mim",
    projetos: "Projetos",
    artigos: "Artigos",
    contatos: "Contate-me",
    
    formulario: {
        titulo: "Titulo",
        email: "Email para retorno",
        mensagem: "Mensagem",
        enviar: "Enviar"
    },
    
    descricao: [
        "Sou um eterno aprendiz, sempre tentando aprender coisas novas para integra-las (mesmo que não possuam a menor semelhança).",
        "Desenvolvedor de jogos pela engine Rpg Maker durante 12 anos (começei aos 8), entretanto não possuo nenhum jogo profissional publicado.",
        "Estagiário pela Embrapa - Arroz e feijão pelo doutor Alexandre Bryan Heinnemann durante 2 anos e meio na área de análise de dados e scripts de automação em R.",
        "Estudante de graduação do curso Engenharia de software pela UFG, desenvolvedor back-end com foco em Java / Android, R / Shiny, e Ruby."
    ],

    footer: {
        def: "Onde estou",
        altitude: "Altitude: 841 metros",
        latitude: "Latitude: -16.7399897",
        longitude: "Longitude: -49.2613339",
        copy: "© MIT licence 2017"
    }
}