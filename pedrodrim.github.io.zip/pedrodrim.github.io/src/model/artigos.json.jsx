export default {
    
    article: [
        {
            "titulo": "Teste",
            "imagem": "src/public/images/template.png",
            "descricao": "Um exemplo de artigo apenas para preencher esta aba.",
            "resumo": "Artigo de teste.",
            "url": "https://github.com/PedroDrim"
        }
    ]    
}