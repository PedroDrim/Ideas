import MainLayout from './layouts/main-layout'
import Footer from './layouts/footer'

ReactDOM.render(
    <MainLayout/>,
    document.getElementById('app')
);

ReactDOM.render(
    <Footer/>,
    document.getElementById('end')
);