import string from '../../model/string.config'

export default class NavigationBar extends React.Component {

    constructor(props) {
        super();
    }

    render() {
        return (
            <div id="id-navigationbar" class="scrollspy">
                <div class="nav-extended navbar-fixed">

                    <ul id="mobile-menu" class="dropdown-content">
                        <li id="mobile-sobre"><a href="#id-sobre">{string.sobre}</a></li>
                        <li id="mobile-projetos"><a href="#id-projetos">{string.projetos}</a></li>
                        <li id="mobile-artigos"><a href="#id-artigos">{string.artigos}</a></li>
                    </ul>

                    <nav>
                        <div class="nav-wrapper container">

                            <a href="#id-navigationbar" class="brand-logo right">{string.DRIM}</a>
                          
                            <ul id="tabnav" class="tabs tabs-transparent hide-on-med-and-down ">
                                <li class="tab"><a href="#id-sobre">{string.sobre}</a></li>
                                <li class="tab"><a href="#id-projetos">{string.projetos}</a></li>
                                <li class="tab"><a href="#id-artigos">{string.artigos}</a></li>
                            </ul>

                            <a class="dropdown-button hide-on-large-only" href='#' data-activates='mobile-menu'>
                                <i class="material-icons">menu</i>
                            </a>

                        </div>
                    </nav>

                </div>
            </div>
        );
    }
}