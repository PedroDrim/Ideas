import string from "../../model/string.config"

export default class Sobre extends React.Component {

    constructor(props) {
        super();
    }

    render() {
        return (
            <div class="container">

                    <div class="col center-align s12">
                        <div id="id-sobre" class="section scrollspy">
                            <span class="flow-text green-text"><strong>{string.sobre}</strong></span>
                        </div>
                    </div>

                    <div class="col center-align s12 m6 l6">
                        <p class="flow-text">{string.descricao[0]}</p>
                        <p class="flow-text">{string.descricao[1]}</p>
                    </div>

                    <div class="col center-align s12 m6 l6">
                        <p class="flow-text">{string.descricao[2]}</p>
                        <p class="flow-text">{string.descricao[3]}</p>
                    </div>

            </div>
        );
    }
}