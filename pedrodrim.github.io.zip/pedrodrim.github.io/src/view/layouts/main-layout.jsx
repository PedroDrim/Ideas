import NavigationBar from './navigation-bar'
import Sobre from './sobre'
import Projetos from './projetos'
import Artigos from './artigos'
import Contatos from './contatos'
import dataProjetos from '../../model/projetos.json'
import dataArtigos from '../../model/artigos.json'

export default class MainLayout extends React.Component {

    constructor(props) {
        super();
    }

    render() {

        return (
            <div class="row">
                <div class="row">
                    <NavigationBar />
                </div>
                <div class="row" id="id-sobre">
                    <Sobre />
                    <Contatos />
                </div>
                <div class="row" id="id-projetos">
                    <Projetos data={dataProjetos.projects}/>
                </div>
                <div class="row" id="id-artigos">
                    <Artigos data={dataArtigos.article}/>
                </div>
            </div>
        );
    }
}
