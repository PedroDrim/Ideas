import string from "../../model/string.config"

export default class Contatos extends React.Component {

    constructor(props) {
        super();
    }

    render() {
        return (
            <div>
                <div class="col center-align s12">
                    <div id="id-contatos" class="section scrollspy">
                        <span class="flow-text green-text"><strong>{string.contatos}</strong></span>
                    </div>
                </div>

                <div class="container">
                    <form action="https://formspree.io/pedrohenriquedrim@gmail.com" method="POST">
                        <div class="row">

                            <div class="input-field col s6">
                                <input id="title_input" type="text" class="validate" name="title" />
                                <label for="title_input">{string.formulario.titulo}</label>
                            </div>

                            <div class="input-field col s6">
                                <input id="email_input" type="email" class="validate" name="email" />
                                <label for="email_input">{string.formulario.email}</label>
                            </div>

                            <div class="input-field col s12">
                                <textarea id="text_input" type="text" class="materialize-textarea" name="name" />
                                <label for="name_input">{string.formulario.mensagem}</label>
                            </div>

                            <button class="btn waves-effect waves-light" type="submit" value="send">{string.formulario.enviar}
                                <i class="material-icons right">send</i>
                            </button>

                        </div>
                    </form>
                </div>
            </div>
        );
    }
}