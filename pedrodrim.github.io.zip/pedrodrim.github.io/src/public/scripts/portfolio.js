$(document).ready(function(){

    var page_tabs = $("#tabnav");
    page_tabs.tabs();

    $('#mobile-sobre').click(function(){
        page_tabs.tabs('select_tab', 'id_sobre');
        location.reload();
    });

    $('#mobile-projetos').click(function(){
        page_tabs.tabs('select_tab', 'id_projetos');
        location.reload();
    });

    $('#mobile-artigos').click(function(){
        page_tabs.tabs('select_tab', 'id_artigos');
        location.reload();
    });
});