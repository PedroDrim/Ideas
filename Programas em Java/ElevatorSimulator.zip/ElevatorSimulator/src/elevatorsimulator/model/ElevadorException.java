/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package elevatorsimulator.model;

/**
 *
 * @author alunoinf
 */
public class ElevadorException extends RuntimeException{
    public ElevadorException(String mensagem){
        super(mensagem);
    }
    
}
