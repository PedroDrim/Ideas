/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package atividadepersistencia.Ex1;

import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;

/**
 *
 * @author alunoinf
 */
public class Exercicio1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        PrintWriter pw;
        try {
            pw = new PrintWriter(args[0], "UTF-8");
            pw.write(args[1]);
            pw.close();
        } catch (FileNotFoundException | UnsupportedEncodingException ex) {}
        
    }
}
