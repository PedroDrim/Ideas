/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package atividadepersistencia.Ex3;

import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

/**
 *
 * @author alunoinf
 */
public class Exercicio3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        
        try {
            FileInputStream fis = new FileInputStream(args[0]);
            DataInputStream dis = new DataInputStream(fis);

            int primeiro = dis.readInt();
            dis.close();

            String primeiroStr = Integer.toHexString(primeiro).toUpperCase();
            System.out.println(primeiroStr);
        } catch (FileNotFoundException ex) {}

    }
}
