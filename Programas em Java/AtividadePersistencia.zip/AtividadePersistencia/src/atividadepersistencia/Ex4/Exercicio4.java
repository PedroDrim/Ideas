/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package atividadepersistencia.Ex4;

import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

/**
 *
 * @author alunoinf
 */
public class Exercicio4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // 89 50 4E 47 0D 0A 1A 0A (.png)

        String assinaturaChave = "89504E470D0A1A0A";

        try {
            FileInputStream fis = new FileInputStream(args[0]);
            DataInputStream dis = new DataInputStream(fis);

            long assinatura = dis.readLong();
            dis.close();

            String assinaturaObtida = Long.toHexString(assinatura).toUpperCase();

            if (assinaturaChave.equals(assinaturaObtida)) {
                System.out.println("Arquivo .png legitimo.");
            } else {
                System.out.println("Nao e arquivo .png.");
            }


        } catch (FileNotFoundException ex) {
            System.err.println(ex.toString());
        }

    }
}
