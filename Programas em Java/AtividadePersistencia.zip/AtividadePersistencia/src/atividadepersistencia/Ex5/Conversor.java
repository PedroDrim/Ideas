/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package atividadepersistencia.Ex5;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

/**
 *
 * @author alunoinf
 */
public class Conversor {

    private FileOutputStream fos;
    private DataOutputStream dos;
    private FileInputStream fis;
    private DataInputStream dis;

    public void convert2Bin(String arquivo, String linha, int code) throws IOException {

        // code = 0 (open)
        // code = 1 (close)

        try {

            if (code == 0) {
                this.fos = new FileOutputStream(arquivo);
                this.dos = new DataOutputStream(this.fos);
            }
            // Gerando bytes da string
            byte[] linhaByte = linha.getBytes();

            // Gerando um vetor int com o tamanho do vetor de bytes
            int tamanho = linhaByte.length;
            int[] linhaInt = new int[tamanho];

            // Escrevendo tamanho de bytes na linha
            this.dos.writeInt(tamanho);

            // Convertendo cada elemento dos bytes em inteiro
            for (int i = 0; i < tamanho; i++) {

                linhaInt[i] = Byte.toUnsignedInt(linhaByte[i]);
                this.dos.writeInt(linhaInt[i]);
            }

            if (code == 1) {
                dos.close();
                fos.close();
            }

        } catch (FileNotFoundException ex) {
            System.err.println(ex.toString());
        }
    }

    public void deconvert2String(String arquivo, int linha, int code) throws IOException {

        // code = 0 (open)
        // code = 1 (close)

        try {

            if (code == 0) {
                this.fis = new FileInputStream(arquivo);
                this.dis = new DataInputStream(this.fis);
            }

            int inteiro = this.dis.readInt();
            int value;

            //dis.skipBytes(linha);
            System.out.print("size: " + inteiro + "\ntexto: ");
            for (int i = 0; i < inteiro; i++) {

                value = this.dis.readInt();
                System.out.print("" + (char) value);
            }
            System.out.println();

            if (code == 1) {
                dis.close();
                fis.close();
            }

        } catch (FileNotFoundException ex) {
            System.err.println(ex.toString());
        }
    }
}
