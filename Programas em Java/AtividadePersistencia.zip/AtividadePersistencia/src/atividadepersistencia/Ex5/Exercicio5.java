/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package atividadepersistencia.Ex5;

import java.io.IOException;

/**
 *
 * @author alunoinf
 */
public class Exercicio5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {

        String arquivoEntrada = "teste.txt";
        String arquivoSaida = "teste.bin";

        Conversor conversor = new Conversor();
        conversor.convert2Bin(arquivoSaida, "teste1", 0);
        conversor.convert2Bin(arquivoSaida, "teste2", 1);
        conversor.deconvert2String(arquivoSaida, 1, 0);
        conversor.deconvert2String(arquivoSaida, 1, 1);

        /*
         try {
         FileInputStream fis = new FileInputStream(arquivoEntrada);
         InputStreamReader isr = new InputStreamReader(fis, "UTF-8");
         BufferedReader br = new BufferedReader(isr);

         String linha;
         while ((linha = br.readLine()) != null) {
         System.out.println(linha);
         }

         br.close();
         } catch (FileNotFoundException | UnsupportedEncodingException ex) {}
         */

    }
}
