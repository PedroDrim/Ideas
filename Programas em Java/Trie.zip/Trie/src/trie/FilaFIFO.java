package trie;

import java.util.Iterator;
import java.util.NoSuchElementException;

/**
 * A estrutura de dados FILA representa uma coleção de objetos com restrição
 * de inserção/remoção do tipo FIFO (First In, First Out).
 * 
 * Ela suporta as operaçoes de: 
 *     (1) inserçao 
 *     (2) consulta 
 *     (3) identificar se uma cadeia esta, ou nao, presente na trie;
 *     (4) remoçao de cadeia;
 *     (5) obter o tamanho, numero de cadeias, da trie;
 *     (6) identificar se a trie esta vazia;
 *     (7) encontrar a cadeia na trie que possui o maior prefixo (fornecido);
 *     (8) encontrar as cadeias da trie que possuem um dado prefixo (fornecido);
 * 
 * A trie utiliza um nodo de 256 direçoes.
 */
public class FilaFIFO<Item> implements Iterable<Item> {
    private Elemento <Item> primeiro;    
    private Elemento <Item> ultimo;     
    private int             NumeroDeElementos;              

  
    private static class Elemento <Item> {
        private Item            item;
        private Elemento <Item> proximo;
    }


    public FilaFIFO() {
        primeiro            = null;
        ultimo              = null;
        NumeroDeElementos   = 0;
    }

    public boolean estaVazia() {
        return primeiro == null;
    }

    public int numeroDeElementos() {
        return NumeroDeElementos;     
    }

 
    public Item primeiroElemento() {
        if (estaVazia()) { 
            throw new NoSuchElementException("Fila: underflow");
        }
        return (primeiro.item);
    }

    public void enfileirar(Item item) {
        Elemento <Item> oldlast = ultimo;
        ultimo          = new Elemento <>();
        ultimo.item     = item;
        ultimo.proximo  = null;
        if (estaVazia()) {
            primeiro = ultimo;
        }
        else {
            oldlast.proximo = ultimo;
        }
        NumeroDeElementos++;
    }

    public Item desenfileirar() {
        if (estaVazia()) {
            throw new NoSuchElementException("Fila: underflow");
        }
        Item item = primeiro.item;
        primeiro    = primeiro.proximo;
        NumeroDeElementos--;
        if (estaVazia()) {
            ultimo = null;
        }   
        return (item);
    }

    @Override
    public String toString() {
        StringBuilder stringAuxiliar = new StringBuilder();
        for (Item item : this) {
            stringAuxiliar.append(item).append(" "); 
        }
        return (stringAuxiliar.toString());
    } 

    @Override
    public Iterator<Item> iterator()  {
        return (new ListIterator<>(primeiro));  
    }
    
    private class ListIterator<Item> implements Iterator<Item> {
        private Elemento <Item> current;

        public ListIterator(Elemento <Item> first) {
            current = first;
        }

        @Override
        public boolean hasNext()  { return (current != null);                 }
        @Override
        public void    remove()   { throw new UnsupportedOperationException();}

        @Override
        public Item next() {
            if (!hasNext()) throw new NoSuchElementException();
            Item item = current.item;
            current   = current.proximo; 
            return (item);
        }
    }
}
