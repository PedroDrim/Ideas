/*==============================================================================
 * Programa exemplo com a implementação, básica, da estrutura de dados TRIE.
 *
 * A trie implementada permite que sejam utilizadas cadeias de caracteres 
 *   (strings) com 256 diferentes simbolos, pois o conjunto de simbolos definido
 *   e a tabela ASCII.
 *  
 * Portanto, esta e uma trie de 256 caminhos possiveis.
 *
 *    por Wanderley de Souza Alencar
 *============================================================================*/
package trie;

import java.util.Scanner;
/**
 * @author Wanderley de Souza Alencar
 */
/**
 * A estrutura de dados TRIE representa uma tabela de simbolos (cadeias de 
 * caracteres) associadas a uma chave (numeros inteiros, neste caso)
 *  
 * Ela suporta as operaçoes de: 
 *     (1) inserçao de cadeia;
 *     (2) consulta a uma cadeia;
 *     (3) identificar se uma cadeia esta, ou nao, presente na trie;
 *     (4) remoçao de cadeia;
 *     (5) obter o tamanho, numero de cadeias, da trie;
 *     (6) identificar se a trie esta vazia;
 *     (7) encontrar a cadeia na trie que possui o maior prefixo (fornecido);
 *     (8) encontrar as cadeias da trie que possuem um dado prefixo (fornecido);
 * 
 * A trie utiliza um nodo de 256 direçoes.
 */

public class Trie <Value> {
    //
    // O conjunto de simbolos utilizado e o dado pela tabela ASCII, que possui
    // 256 simbolos distintos.
    //
    private static final int NUMERO_DE_SIMBOLOS = 256;        
    //
    // Raiz da trie e o numero de elementos que esta nela armazenado
    //
    private Nodo raiz;      
    private int NumeroDeElementos;          
    //
    // Estrutura do no, ou nodo, da trie
    //
    private static class Nodo {
        private Object valorArmazenado;
        private Nodo[] next = new Nodo[NUMERO_DE_SIMBOLOS];
    }

   /*--------------------------------------------------------------------------
     * Inicializa a trie -- vazia
     *-----------------------------------------------------------------------*/
    public Trie() {
    }
    /**-------------------------------------------------------------------------
     * Retorna o valor associado a chave fornecida, ou seja, recupera a 
     * informacao armazenada naquele Nodo da trie.
     * @param chaveDesejada  chave desejada.
     * @return o valor associado com a chave desejada, se ela existir na trie.            
     *         ou retorna null, se inexistente.                        
     * @throws NullPointerException se a chave desejada for nula.                                      
     *------------------------------------------------------------------------*/
    public Value recuperarNodo(String chaveDesejada) {
        Nodo nodoAuxilliar = recuperarNodo(raiz, chaveDesejada, 0);
        if (nodoAuxilliar == null) {
            return (null);
        }
        return (Value) nodoAuxilliar.valorArmazenado;
    }

    private Nodo recuperarNodo(Nodo nodoFornecido, String chaveDesejada, int d) {
        if (nodoFornecido == null) { 
            return (null); 
        }
        if (d == chaveDesejada.length()) { 
            return (nodoFornecido); 
        }
        char caracterAuxiliar = chaveDesejada.charAt(d);
        return (recuperarNodo(nodoFornecido.next[caracterAuxiliar], chaveDesejada, d+1));
    }
      
    /**-------------------------------------------------------------------------
     * Retorna TRUE se a trie contem a chave dada ou FALSE, do contrario. 
     * @param chaveDesejada chave desejada.
     * @return TRUE se a trie contem a chave desejada e FALSE do contrario. 
     * @throws NullPointerException se a chave desejada for nula.
     **-----------------------------------------------------------------------*/
    public boolean chaveExiste(String chaveDesejada) {
        return (recuperarNodo(chaveDesejada) != null);
    }

    /**--------------------------------------------------------------------------
     * Insere a chaveFornecida na trie. Se a chave ja existe, esta sera sobre-
     * posta pelo valor atual. Se o valorFornecido for null, entao ele remove a
     * chaveFornecida da trie.
     * @param chaveFornecida chave fornecida
     * @param valorFornecido  valor a ser inserido, ou null para remove-lo da trie.
     * @throws NullPointerException se a chaveFornecida for null.
     *------------------------------------------------------------------------*/
    public void inserirChave(String chaveFornecida, Value valorFornecido) {
        if (valorFornecido == null) { 
            removerChave(chaveFornecida); 
        }
        else { 
            raiz = inserirChave(raiz, chaveFornecida, valorFornecido, 0); 
        }
    }

    private Nodo inserirChave(Nodo nodoFornecido, String key, Value valorFornecido, int d) {
        if (nodoFornecido == null) {
            nodoFornecido = new Nodo();
        }
        if (d == key.length()) {
            if (nodoFornecido.valorArmazenado == null) { 
                NumeroDeElementos++; 
            }
            nodoFornecido.valorArmazenado = valorFornecido;
            return (nodoFornecido);
        }
        char caracterAuxiliar                = key.charAt(d);
        nodoFornecido.next[caracterAuxiliar] = inserirChave(nodoFornecido.next[caracterAuxiliar], key, valorFornecido, d+1);
        return nodoFornecido;
    }

    /**------------------------------------------------------------------------
     * Retorna o numero de elementos presentes na trie.             
     * @return Numero de elementos presentes na trie                   
     *------------------------------------------------------------------------*/
    public int numeroElementos() {
        return (NumeroDeElementos);
    }

    /**-------------------------------------------------------------------------
     * A trie esta vazia? Returna TRUE se estiver e, FALSE do contrario
     * @return  Retorna TRUE, se a trie estiver vazia. FALSE, do contrario.
     */
    public boolean estaVazia() {
        return (numeroElementos() == 0);
    }

    /**------------------------------------------------------------------------
     * Retorna todas as chaves presentes na trie sob a forma de um 
     * Iterable. 
     * Para "varrer" todas as chaves, basta que utilize a notacao "foreach".
     * @return todas as cadeias armazenadas na trie
     *-----------------------------------------------------------------------*/
    public Iterable <String> chavesDaTrie() {
        return (chavesComPrefixo(""));
    }

    /**-------------------------------------------------------------------------
     * Retorna todas as chaves que são iniciadas com o prefixoFornecido.
     * @param prefixoFornecido prefixo fornecido
     *-------------------------------------------------------------------------*/
    public Iterable<String> chavesComPrefixo(String prefixoFornecido) {
        FilaFIFO <String> resultadoPesquisa = new FilaFIFO<String>();
        Nodo nodoAuxiliar = recuperarNodo(raiz, prefixoFornecido, 0);
        colecionar(nodoAuxiliar, new StringBuilder(prefixoFornecido), resultadoPesquisa);
        return (resultadoPesquisa);
    }

    /**------------------------------------------------------------------------
     * Retorna todas as chaves na trie que obedecem ao padraoFornecido, onde o 
     * simbolo . (ponto) e tratado como um "simbolo coringa", ou seja, que 
     * representa qualquer outro simbolo. 
     * @param padraoFornecido padrão fornecido para pesquisa
     * @return todas as chaves que obedecem ao padraoFornecido, como um 
     *         iterable
     *------------------------------------------------------------------------*/
    public Iterable<String> chavesComPadrao(String padraoFornecido) {
        FilaFIFO<String> resultados = new FilaFIFO<String>();
        colecionar(raiz, new StringBuilder(), padraoFornecido, resultados);
        return resultados;
    }
    
    private void colecionar(Nodo nodoFornecido, StringBuilder prefixoFornecido, FilaFIFO<String> resultado) {
        if (nodoFornecido == null) { 
            return;
        }
        if (nodoFornecido.valorArmazenado != null) { 
            resultado.enfileirar(prefixoFornecido.toString());
        }
        for (char c = 0; c < NUMERO_DE_SIMBOLOS; c++) {
            prefixoFornecido.append(c);
            colecionar(nodoFornecido.next[c], prefixoFornecido, resultado);
            prefixoFornecido.deleteCharAt(prefixoFornecido.length() - 1);
        }
    }

    private void colecionar(Nodo nodoFornecido, StringBuilder prefixoFornecido, String PadraoFornecido, FilaFIFO<String> resultado) {
        if (nodoFornecido == null) { 
            return;
        }
        int tamanho = prefixoFornecido.length();
        if (tamanho == PadraoFornecido.length() && (nodoFornecido.valorArmazenado != null)) {
            resultado.enfileirar(prefixoFornecido.toString());
        }    
        if (tamanho == PadraoFornecido.length()) {
            return;
        }
        char caracterAuxiliar = PadraoFornecido.charAt(tamanho);
        if (caracterAuxiliar == '.') {
            for (char caractere = 0; caractere < NUMERO_DE_SIMBOLOS; caractere++) {
                prefixoFornecido.append(caractere);
                colecionar(nodoFornecido.next[caractere], prefixoFornecido, PadraoFornecido, resultado);
                prefixoFornecido.deleteCharAt(prefixoFornecido.length() - 1);
            }
        }
        else {
            prefixoFornecido.append(caracterAuxiliar);
            colecionar(nodoFornecido.next[caracterAuxiliar], prefixoFornecido, PadraoFornecido, resultado);
            prefixoFornecido.deleteCharAt(prefixoFornecido.length() - 1);
        }
    }

    /**------------------------------------------------------------------------
     * Retorna a cadeia de caracteres na trie que possui o "mais extenso"/"mais longo" 
     * prefixo dado em prefixoFornecido. Retorna null se não há esta cadeia.
     * @param prefixoFornecido a cadeia prefixo
     * @return a cadeia de caracteres da trie que possui o mais longo prefisso expresso em 
     * @throws NullPointerException se prefixoFornecido é null.
     *------------------------------------------------------------------------*/
    public String maiorPrefixoDe(String prefixoFornecido) {
        int tamanho = maiorPrefixoDe(raiz, prefixoFornecido, 0, -1);
        if (tamanho == -1) { 
            return (null); 
        } 
        else { 
            return (prefixoFornecido.substring(0, tamanho));
        }
    }

    /**------------------------------------------------------------------------
     * Retorna o tamanho (comprimento) do mais longa cadeia de caracteres na 
     *  subarvore cuja raiz é nodoFornecido, cujo prefixo corresponde ao 
     *  prefixoFornecido. Assume que os primeiros "d" caracteres são iguais e 
     *  que já foi encontrado um casamento de prefixo de certo comprimento (-1
     *  se não foi encontrado este casamento)
     *------------------------------------------------------------------------*/
    
    private int maiorPrefixoDe(Nodo nodoFornecido, String prefixoFornecido, int d, int tamanho) {
        if (nodoFornecido == null) { 
            return tamanho;
        }
        if (nodoFornecido.valorArmazenado != null) { 
            tamanho = d;
        }
        if (d == prefixoFornecido.length()) { 
            return tamanho;
        }
        char caractereAuxiliar = prefixoFornecido.charAt(d);
        return (maiorPrefixoDe(nodoFornecido.next[caractereAuxiliar], prefixoFornecido, d+1, tamanho));
    }

    /**
     * Remove a chaveDesejada da trie, se ela estiver presente.
     * @param chaveDesejada chave para remoção
     * @throws NullPointerException se a chaveDesejada for null
     */
    public void removerChave(String chaveDesejada) {
        raiz = removerChave(raiz, chaveDesejada, 0);
    }

    private Nodo removerChave(Nodo nodoFornecido, String chaveDesejada, int tamanho) {
        if (nodoFornecido == null) { 
            return null;
        }
        if (tamanho == chaveDesejada.length()) {
            if (nodoFornecido.valorArmazenado != null) NumeroDeElementos--;
            nodoFornecido.valorArmazenado = null;
        }
        else {
            char c = chaveDesejada.charAt(tamanho);
            nodoFornecido.next[c] = removerChave(nodoFornecido.next[c], chaveDesejada, tamanho+1);
        }
        // 
        // Remove a subárvore cuja raiz é nodoFornecido, desde que ela esteja 
        // vazia. 
        //
        if (nodoFornecido.valorArmazenado != null) { 
            return nodoFornecido;
        }
        for (int caractere = 0; caractere < NUMERO_DE_SIMBOLOS; caractere++) { 
            if (nodoFornecido.next[caractere] != null) { 
                return (nodoFornecido);
            }
        }
        return (null);
    }
    //
    /*==========================================================================
     * Programa Principal
     *========================================================================*/
    //
    public static void main(String[] args) {
        int     contaPalavras;
        String  auxiliarString;
        Scanner dadosEntrada;
        
        dadosEntrada         = new Scanner(System.in);
        //
        // Contrói, a partir da entrada de dados fornecida pelo usuário, 
        // a trie.
        //
        Trie<Integer> arvoreTrie = new Trie<Integer>();
        System.out.println("Forneça as PALAVRAS que deseja inserir na TRIE.");
        System.out.println("  use a palavra * (asterisco) para encerrar a entrada.");
        contaPalavras = 0;
        auxiliarString = "";
        while (!(auxiliarString.equalsIgnoreCase("*"))) {
            System.out.print("Palavra [ " + contaPalavras + "]: ");
            auxiliarString = dadosEntrada.next();
            System.out.println();
            
            if (!(auxiliarString.equalsIgnoreCase("*"))) {
                arvoreTrie.inserirChave(auxiliarString, contaPalavras);
                contaPalavras++;
            }
        }
        //
        // Apresenta, na tela, as chaves armazenadas... desde que ela tenha 
        // menos de 100 elementos.
        //
        if (arvoreTrie.numeroElementos() < 100) {
            System.out.println("Chaves da TRIE:");
            for (String chaveAuxiliar : arvoreTrie.chavesDaTrie()) {
                System.out.println(chaveAuxiliar + "- [" + arvoreTrie.recuperarNodo(chaveAuxiliar) + "]");
            }
            System.out.println();
        }
        //
        // Fornece informações sobre a trie...
        //
        System.out.println("Forneça um PREFIXO para ser identificado na TRIE.");
        System.out.println("  use a palavra * (asterisco) para encerrar a entrada de palavras.");
        auxiliarString = "";
        while (!(auxiliarString.equalsIgnoreCase("*"))) {
            System.out.print("Prefixo: ");
            auxiliarString = dadosEntrada.next();
            System.out.println();
            
            if (!(auxiliarString.equalsIgnoreCase("*"))) {
               System.out.println("A palavra de maior prefixo " + auxiliarString + " é a seguinte: " + arvoreTrie.maiorPrefixoDe(auxiliarString)); 
               System.out.println();
               
               System.out.println("As palavras que possue o prefixo " + auxiliarString + " são as seguintes: ");
               for (String s : arvoreTrie.chavesComPrefixo(auxiliarString)) {
                    System.out.println(s);
               }
               System.out.println();
               System.out.println("Forneça um PADRÃO para selecionar cadeias na TRIE.");
               System.out.println("  use o SÍMBOLO PONTO como caractere curinga e");
               System.out.println("  a palavra * (asterisco) para encerrar a entrada.");
               System.out.print("Padrão: ");
               auxiliarString = dadosEntrada.next();
               System.out.println();
               
               if (!(auxiliarString.equalsIgnoreCase("*"))) {
                  System.out.println("As chaves que seguem o padrão " + auxiliarString + " são as seguintes: ");
                  for (String s : arvoreTrie.chavesComPadrao(auxiliarString)) {
                      System.out.println(s);
                  }
               }
            }
        }        
        System.out.println();
    }
}

