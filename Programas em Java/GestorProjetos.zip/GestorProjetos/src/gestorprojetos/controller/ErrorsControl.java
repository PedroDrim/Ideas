/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gestorprojetos.controller;

import java.util.Scanner;

/**
 *
 * @author alunoinf
 */
public abstract class ErrorsControl {

    private Scanner scan = new Scanner(System.in);

    public int getInt() {
        String nome;
        int id;

        do {
            nome = scan.nextLine();

            try {
                id = Integer.parseInt(nome);
                return id;
            } catch (RuntimeException erro) {
                throw new IllegalArgumentException("Insira um número inteiro");
            }
        } while (true);
    }

    public String getString() {
        String nome = scan.nextLine();
        
        if((nome == null) || (nome.equals(""))){
            throw new IllegalArgumentException("Insira um nome.");
        }
        
        return nome;
    }
}
