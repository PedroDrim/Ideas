/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gestorprojetos.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 *
 * @author alunoinf
 */
public class GeradorId {

    private static List<Integer> listaId = new ArrayList<>();
    private static GeradorId instancia;

    private GeradorId() {
    }

    public static GeradorId getInstance() {
        if (instancia == null) {
            instancia = new GeradorId();
        }

        return instancia;
    }

    public int CreateId(int casas) {
        Random random = new Random();

        do {
            int id = (int) (Math.pow(10, casas) * random.nextDouble());

            if (!listaId.contains(id)) {
                listaId.add(id);
                return id;
            }
        } while (true);
    }
}
