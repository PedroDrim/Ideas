/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gestorprojetos.model;

import gestorprojetos.controller.ExceptionTarefas;
import java.util.Calendar;

/**
 *
 * @author alunoinf
 */
public class SubTarefa extends TemplateTarefas {

    private boolean concluido = false;

    public SubTarefa(String nome, String descricao) {
        if ((nome == null) || (descricao == null)) {
            throw new ExceptionTarefas("Os campos descrição e nome devem ser preenchidos corretamente.");
        }

        super.setDescricao(descricao);
        super.setNome(nome);
    }

    public void concuirSubTarefa() {
        this.concluido = true;
        setDataFim(Calendar.getInstance());
    }

    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();

        builder.append("Nome da sub-tarefa : ");
        builder.append(getNome());
        builder.append(" (");
        builder.append(getId());
        builder.append(")");
        builder.append("\n");
        builder.append("    Descrição: ");
        builder.append(getDescricao());
        builder.append("\n");

        if (concluido) {
            builder.append("    Status da sub-tarefa : Concluido.");
            builder.append("\n");
            builder.append("    Data de inicio : ");
            builder.append(getDataInicio());
            builder.append("\n");
            builder.append("    Data do término : ");
            builder.append(getDataFim().getTime());

        } else {
            builder.append("    Status da sub-tarefa : Em andamento.");
            builder.append("\n");
            builder.append("    Inicio : ");
            builder.append(getDataInicio().getTime());
        }

        builder.append("\n");
        builder.append("\n");

        return builder.toString();
    }
}
