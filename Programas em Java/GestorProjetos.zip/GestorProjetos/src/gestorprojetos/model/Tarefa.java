/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gestorprojetos.model;

import gestorprojetos.controller.ExceptionTarefas;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

/**
 *
 * @author alunoinf
 */
public class Tarefa extends TemplateTarefas {

    private List<SubTarefa> listaSubTarefas = new ArrayList<>();
    private List<Pessoa> listaPessoas = new ArrayList<>();
    private boolean concluido = false;

    public Tarefa(String nome, String descricao) {
        if ((nome == null) || (descricao == null)) {
            throw new ExceptionTarefas("Os campos descrição e nome devem ser preenchidos corretamente.");
        }

        super.setDescricao(descricao);
        super.setNome(nome);
    }

    public void adicionarPessoa(Pessoa pessoa) {
        listaPessoas.add(pessoa);
    }

    public void removerPessoa(int id) {
        Pessoa pessoa;

        if (id < 0) {
            throw new ExceptionTarefas("Não existe identificadores negativos.");
        }

        for (int contador = 0; contador < listaPessoas.size(); contador++) {
            pessoa = listaPessoas.get(contador);

            if (pessoa.getId() == id) {
                listaPessoas.remove(contador);
                return;
            }
        }
        throw new ExceptionTarefas("Não existe uma pessoa atribuida ao id " + id + ".");
    }

    public void adicionarSubTarefa(SubTarefa subTarefa) {
        listaSubTarefas.add(subTarefa);
    }

    public void removerSubTarefa(int id) {
        SubTarefa subTarefa;

        if (id < 0) {
            throw new ExceptionTarefas("Não existe identificadores negativos.");
        }

        for (int contador = 0; contador < listaSubTarefas.size(); contador++) {
            subTarefa = listaSubTarefas.get(contador);

            if (subTarefa.getId() == id) {
                listaSubTarefas.remove(contador);
                return;
            }

        }
        throw new ExceptionTarefas("Não existe uma tarefa atribuida ao id " + id + ".");
    }

    public void concuirSubTarefa(int id) {
        SubTarefa subTarefa;

        if (id < 0) {
            throw new ExceptionTarefas("Não existe identificadores negativos.");
        }

        for (int contador = 0; contador < listaSubTarefas.size(); contador++) {
            subTarefa = listaSubTarefas.get(contador);

            if (subTarefa.getId() == id) {
                subTarefa.concuirSubTarefa();
                return;
            }

        }
        throw new ExceptionTarefas("Não existe uma tarefa atribuida ao id " + id + ".");
    }

    public void concuirTarefa() {
        SubTarefa subTarefa;

        for (SubTarefa listaSubTarefa : listaSubTarefas) {
            subTarefa = listaSubTarefa;
            subTarefa.concuirSubTarefa();
        }

        this.concluido = true;
        setDataFim(Calendar.getInstance());
    }

    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();

        builder.append("Nome da tarefa : ");
        builder.append(getNome());
        builder.append(" (");
        builder.append(getId());
        builder.append(")");
        builder.append("\n");
        builder.append("Envolvidos: ");
        builder.append("\n");
        builder.append("Descrição: ");
        builder.append(getDescricao());
        builder.append("\n");

        for (int contador = 0; contador < listaPessoas.size(); contador++) {
            Pessoa pessoa = listaPessoas.get(contador);

            builder.append(contador + 1);
            builder.append(" - ");
            builder.append(pessoa.getNome());
            builder.append(" (");
            builder.append(pessoa.getId());
            builder.append(")");
            builder.append("\n");
        }

        builder.append("\n");
        builder.append("Sub-tarefas: ");
        builder.append("\n");

        for (int contador = 0; contador < listaSubTarefas.size(); contador++) {
            SubTarefa subtarefa = listaSubTarefas.get(contador);

            builder.append("(");
            builder.append(contador + 1);
            builder.append(") ");

            builder.append(subtarefa.toString());
        }

        if (concluido) {
            builder.append("Status da tarefa : Concluido.");
            builder.append("\n");
            builder.append("Data de inicio : ");
            builder.append(getDataInicio());
            builder.append("\n");
            builder.append("Data do término : ");
            builder.append(getDataFim().getTime());

        } else {
            builder.append("Status da tarefa : Em andamento.");
            builder.append("\n");
            builder.append("Inicio : ");
            builder.append(getDataInicio().getTime());
        }

        builder.append("\n");

        return builder.toString();
    }
}
