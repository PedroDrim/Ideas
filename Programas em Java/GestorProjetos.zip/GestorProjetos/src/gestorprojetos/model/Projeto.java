/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gestorprojetos.model;

import gestorprojetos.controller.GeradorId;
import java.util.*;

/**
 *
 * @author alunoinf
 */
public class Projeto {
    
    private String nome;
    private int identificaçao;
    private Pessoa gerente;
    private List<Tarefa> tarefas = new ArrayList();
    private Tarefa tarefa;
    
    
    public Projeto(String nome){
        this.nome = nome;
        this.identificaçao = GeradorId.getInstance().CreateId(6);
    }
    
    public String getNome(){
        return this.nome;
    }
    
    public int getIdentificaçao(){
        return this.identificaçao;
    }
    public void escolherGerente(Pessoa pessoa){
        Pessoa gerente = pessoa;
    }
    public void listaTarefa(){
        Iterator auxiliar = tarefas.iterator();
        while(auxiliar.hasNext()){
            auxiliar.next();
        }
    }
    public void addTarefa(Tarefa tarefa){
        
        tarefas.add(tarefa);
    }
    public void searchTarefa(int identidadeTarefa, boolean confirmaçao){
       
        for(int contador = 0; contador < tarefas.size(); contador++){
             Tarefa temporario = tarefas.get(contador);
           if(temporario.getId() == identidadeTarefa){
               confirmaçao = true;
               temporario.getDescricao();
               temporario.getNome();
               temporario.getDataInicio();
               temporario.getDataFim();
           }
        }
    }

    @Override
    public String toString() {
        StringBuilder builder = new  StringBuilder();
        
        builder.append("Nome do projeto : ");
        builder.append(nome);
        builder.append(" (");
        builder.append(identificaçao);
        builder.append(")");
        builder.append("\n");
        builder.append("Nome do gerente : ");
        builder.append(gerente.getNome());
        builder.append(" (");
        builder.append(gerente.getId());
        builder.append(")");
        builder.append("\n");
        
        return builder.toString();
    }
    
    
}
