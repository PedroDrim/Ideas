/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gestorprojetos.view;

import gestorprojetos.controller.ErrorsControl;
import gestorprojetos.model.Pessoa;
import gestorprojetos.model.Projeto;
import gestorprojetos.model.SubTarefa;
import gestorprojetos.model.Tarefa;
import java.util.ArrayList;
import java.util.*;

/**
 *
 * @author alunoinf
 */
public class Menu extends ErrorsControl {

    List<Projeto> projetos = new ArrayList<>();
    List<Tarefa> tarefas = new ArrayList<>();
    List<Pessoa> pessoas = new ArrayList<>();
    List<SubTarefa> subtarefas = new ArrayList<>();

    public Menu() {
        System.out.println("Escolha uma das seguintes operações");
        while (true) {
            System.out.println("1 - Criar novo Projeto  2 - Criar Pessoa ");
            System.out.println("3 - Criar tarefa    4- Criar Subtarefa");
            System.out.println("5 - Adicionar gerente a projeto  6 - Adicionar pessoa a tarefa");
            System.out.println("7 - Adicionar sub-tarefa a tarefa   8 - listar projetos");
            System.out.println("9 - listar pessoas  10 - listar tarefas");
            System.out.println("11 - listar sub-tarefas     12 - sair");

            int opcao;
            do {
                System.out.println("digita a opcao\n");
                try {
                    opcao = getInt();
                    break;
                } catch (IllegalArgumentException erro) {
                    System.out.println(erro.getMessage());
                }

            } while (true);

            switch (opcao) {
                case 1:
                    criarProjeto();
                    break;
                case 2:
                    CriarPessoa();
                    break;
                case 3:
                    CriarTarefa();
                    break;
                case 4:
                    break;
                case 5:

                    break;
                case 6:

                    break;
                case 7:

                    break;
                case 8:
                    listarProjeto();
                    break;
                case 9:
                    listarPessoas();
                    break;
                case 10:
                    listarTarefa();
                    break;
                case 11:
                    listarSubTarefa();
                    break;
                case 12:
                    System.out.println("Saindo");
                    return;
                default:
                    System.out.println("Insira uma poção valida");
            }
        }
    }

    public void CriarPessoa() {
        String nomePessoa, telefone;

        System.out.println("Diga o nome e o telefone\n");

        do {
            System.out.println("nome\n");

            try {
                nomePessoa = getString();
                break;
            } catch (IllegalArgumentException erro) {
                System.out.println(erro.getMessage());
            }

        } while (true);

        do {
            System.out.println("telefone\n");
            try {
                telefone = getString();
                break;
            } catch (IllegalArgumentException erro) {
                System.out.println(erro.getMessage());
            }

        } while (true);

        pessoas.add(new Pessoa(nomePessoa, telefone));
    }

    public void criarProjeto() {
        String nomeProjeto;

        System.out.println("diga o nome do projeto\n");
        do {
            System.out.println("nome\n");
            try {
                nomeProjeto = getString();
                break;
            } catch (IllegalArgumentException erro) {
                System.out.println(erro.getMessage());
            }

        } while (true);

        projetos.add(new Projeto(nomeProjeto));

    }

    public void CriarTarefa() {
        String nomeTarefa, descriçao;

        System.out.println("Diga o nome, e a descrição da tarefa\n");

        do {
            System.out.println("nome\n");

            try {
                nomeTarefa = getString();
                break;
            } catch (IllegalArgumentException erro) {
                System.out.println(erro.getMessage());
            }

        } while (true);

        do {
            System.out.println("descrição\n");
            try {
                descriçao = getString();
                break;
            } catch (IllegalArgumentException erro) {
                System.out.println(erro.getMessage());
            }

        } while (true);

        tarefas.add(new Tarefa(nomeTarefa, descriçao));
    }

    public void CriarSubTarefa() {
        String nomeTarefa, descriçao;

        System.out.println("Diga o nome, e a descrição da subtarefa\n");

        do {
            System.out.println("nome\n");

            try {
                nomeTarefa = getString();
                break;
            } catch (IllegalArgumentException erro) {
                System.out.println(erro.getMessage());
            }

        } while (true);

        do {
            System.out.println("descrição\n");
            try {
                descriçao = getString();
                break;
            } catch (IllegalArgumentException erro) {
                System.out.println(erro.getMessage());
            }

        } while (true);

        subtarefas.add(new SubTarefa(nomeTarefa, descriçao));
    }

    public void listarPessoas() {

        System.out.println();
        for (Pessoa pessoa : pessoas) {
            System.out.print("Nome :");
            System.out.print(pessoa.getNome());
            System.out.print(" (");
            System.out.print(pessoa.getId());
            System.out.println(")");
            System.out.println("Telefone :" + pessoa.getTelefone());
            System.out.println();
        }
    }

    public void listarTarefa() {

        System.out.println();
        for (Tarefa auxiliar : tarefas) {
            System.out.print("Nome :");
            System.out.print(auxiliar.getNome());
            System.out.print(" (");
            System.out.print(auxiliar.getId());
            System.out.println(")");
            System.out.println("descrição :" + auxiliar.getDescricao());
            System.out.println();
        }
    }

    public void listarSubTarefa() {

        System.out.println();
        for (SubTarefa auxiliar : subtarefas) {
            System.out.print("Nome :");
            System.out.print(auxiliar.getNome());
            System.out.print(" (");
            System.out.print(auxiliar.getId());
            System.out.println(")");
            System.out.println("descrição :" + auxiliar.getDescricao());
            System.out.println();
        }
    }

    public void listarProjeto() {

        System.out.println();
        for (Projeto auxiliar : projetos) {
            System.out.print("Nome :");
            System.out.print(auxiliar.getNome());
            System.out.print(" (");
            System.out.print(auxiliar.getIdentificaçao());
            System.out.println(")");
            System.out.println();
        }
    }

    public Pessoa buscarPessoa() {
        int id;

        do {
            System.out.println("insira a identificação \n");
            try {
                id = getInt();

                for (Pessoa pessoa : pessoas) {
                    if (pessoa.getId() == id) {
                        return pessoa;
                    }
                }

            } catch (IllegalArgumentException erro) {
                System.out.println(erro.getMessage());
            }

        } while (true);
    }

    public Tarefa buscarTarefas() {
        int id;

        do {
            System.out.println("insira a identificação \n");
            try {
                id = getInt();

                for (Tarefa tarefa : tarefas) {
                    if (tarefa.getId() == id) {
                        return tarefa;
                    }
                }

            } catch (IllegalArgumentException erro) {
                System.out.println(erro.getMessage());
            }

        } while (true);
    }

    public SubTarefa buscarSubTarefas() {
        int id;

        do {
            System.out.println("insira a identificação \n");
            try {
                id = getInt();

                for (SubTarefa subtarefa : subtarefas) {
                    if (subtarefa.getId() == id) {
                        return subtarefa;
                    }
                }

            } catch (IllegalArgumentException erro) {
                System.out.println(erro.getMessage());
            }

        } while (true);
    }

    public Projeto buscarProjetos() {
        int id;

        do {
            System.out.println("insira a identificação \n");
            try {
                id = getInt();

                for (Projeto projeto : projetos) {
                    if (projeto.getIdentificaçao() == id) {
                        return projeto;
                    }
                }

            } catch (IllegalArgumentException erro) {
                System.out.println(erro.getMessage());
            }

        } while (true);
    }

    public void adicionarGerente() {
        Pessoa pessoa = null;
        Projeto projeto1 = null;
        boolean loop = true;
        int id;

        do {
            

            System.out.println("insira a identificação da pessoa \n");
            try {
                id = getInt();

                for (Pessoa projeto : pessoas) {
                    if (projeto.getId() == id) {
                        pessoa = projeto;
                        loop = false;
                    }
                }

            } catch (IllegalArgumentException erro) {
                System.out.println(erro.getMessage());
            }

        } while (loop);

        loop = true;
        do {
            System.out.println("insira a identificação do projeto \n");
            try {
                id = getInt();

                for (Projeto projeto : projetos) {
                    if (projeto.getIdentificaçao() == id) {
                        projeto1 = projeto;
                        loop = false;
                    }
                }

            } catch (IllegalArgumentException erro) {
                System.out.println(erro.getMessage());
            }

        } while (loop);
        
        projeto1.escolherGerente(pessoa);
    }
}
