/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package battleroyalle.controler;

import battleroyalle.model.Participante;
import java.util.Random;

/**
 *
 * @author alunoinf
 */
public class SystemControl {

    public static double arredondamento(double valor) {
        double retorno = Math.ceil(valor * 100);

        return retorno / 100;
    }

    public static void ending(Participante participante) {
        if (participante.getVidaAtual() <= 0) {
            System.out.println(participante.getNome() + " foi derrotado.");
            System.exit(0);
        }
    }

    public static double criticalChance(double valor) {
        Random random = new Random();
        int coeficienteCritico = random.nextInt(100);

        if (coeficienteCritico >= 90) {
            System.out.println("CRÍTICO !!!");
        }

        return valor * (100 + coeficienteCritico) / 100;
    }
}
