/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package battleroyalle.controler;

import java.util.Scanner;

/**
 *
 * @author alunoinf
 */
public abstract class ErrorsControl {

    private Scanner scan = new Scanner(System.in);

    public int getInt() {
        int resposta = 0;

        do {
            try {
                resposta = Integer.parseInt(scan.nextLine());
                break;
            } catch (RuntimeException erro) {
                System.err.println("Digite um numero inteiro.");
            }
        } while (true);
        
        return resposta;
    }
  
}
