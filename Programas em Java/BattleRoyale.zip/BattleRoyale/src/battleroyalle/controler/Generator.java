/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package battleroyalle.controler;

import battleroyalle.model.Fighter;
import battleroyalle.model.Humano;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author alunoinf
 */
public class Generator {

    private static Generator instance;
    private Random random = new Random();
    private Scanner scan = new Scanner(System.in);
    private List<Integer> listaId = new ArrayList<>();

    private Generator() {
    }

    public static Generator getInstance() {
        if (instance == null) {
            instance = new Generator();
        }

        return instance;
    }

    private int createId() {
        int id = 1;

        do {
            if (!listaId.contains(id)) {
                listaId.add(id);
                return id;
                
            } else {
                id++;
            }
        } while (true);
    }

    public Fighter createFighter() {
        String nome = scan.nextLine();
        int nivel = random.nextInt(10) + 1;

        Fighter retorno = new Humano(createId() ,nome, nivel);
        return retorno;
    }
}
