/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package battleroyalle.model;

/**
 *
 * @author alunoinf
 */
public interface Fighter {
    public void atacar(Fighter oponente);
    public void receberGolpe(double vida);
    public void defender();
    public void desviar();
    public String getStatus();
    public String getNome();
}
