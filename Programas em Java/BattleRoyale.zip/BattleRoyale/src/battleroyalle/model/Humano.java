/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package battleroyalle.model;

import battleroyalle.controler.Generator;
import battleroyalle.controler.SystemControl;
import java.util.Random;

/**
 *
 * @author alunoinf
 */
public class Humano implements Participante, Fighter {
    
    private int id;
    
    private String nome;
    private int level;
    private double vidaMaxima;
    private double vidaAtual;
    private double forca;
    private double defesa;
    private double agilidade;

    private boolean defender = false;
    private boolean desviar = false;

    public Humano(int id , String nome, int level) {
        this.id = id;
        this.nome = nome;
        this.level = level;
        vidaMaxima = 100 * (10 + (level - 1)) / 10;
        vidaAtual = vidaMaxima;
        forca = 10 * (10 + (level - 1)) / 10;
        defesa = 10 * (10 + (level - 1)) / 10;
        agilidade = 10 * (10 + (level - 1)) / 10;
    }

    @Override
    public String getNome() {
        return nome;
    }

    @Override
    public double getVidaMaxima() {
        return vidaMaxima;
    }

    @Override
    public double getVidaAtual() {
        return vidaAtual;
    }

    @Override
    public double getForca() {
        return forca;
    }

    @Override
    public double getDefesa() {
        return defesa;
    }

    @Override
    public double getAgilidade() {
        return agilidade;
    }

    @Override
    public void dropVida(double vida) {
        int fatorDesvio = (int) Math.abs(getAgilidade());
        double valorReal;
        Random aleatorio = new Random();

        if ((desviar) && (aleatorio.nextInt(fatorDesvio) < (fatorDesvio + 1) / 2)) {
            vidaAtual -= 0;
            System.out.println(getNome() + " desviou.");
        } else if (defender) {
            valorReal = SystemControl.criticalChance(vida);
            vidaAtual -= (valorReal - (defesa / 10));
            System.out.println(getNome() + " perdeu " + (vida - (defesa / 10)) + " hp.");
        } else {
            valorReal = SystemControl.criticalChance(vida);
            vidaAtual -= valorReal;
            System.out.println(getNome() + " perdeu " + valorReal + " hp.");
        }
        
        System.out.println();
        SystemControl.ending(this);
    }

    @Override
    public void receberGolpe(double vida) {
        dropVida(vida);
    }

    @Override
    public void levelUp() {
        forca *= 1.2;
        defesa *= 1.1;
        agilidade *= 1.2;
        level += 1;
    }

    @Override
    public int getLevel() {
        return level;
    }

    @Override
    public void atacar(Fighter oponente) {
        defender = false;
        desviar = false;

        oponente.receberGolpe(getForca());
    }

    @Override
    public void defender() {
        defender = true;
    }

    @Override
    public void desviar() {
        desviar = true;
    }

    @Override
    public String getStatus() {
        StringBuilder builder = new StringBuilder();

        builder.append("Level: ");
        builder.append(getLevel());
        builder.append("\n");
        builder.append("Nome: ");
        builder.append(getNome());
        builder.append("\n");
        builder.append("Vida: ");
        builder.append(SystemControl.arredondamento(getVidaMaxima()));
        builder.append("/");
        builder.append(SystemControl.arredondamento(getVidaAtual()));
        builder.append("\n");
        builder.append("Força: ");
        builder.append(getForca());
        builder.append("\n");
        builder.append("Defesa: ");
        builder.append(getDefesa());
        builder.append("\n");
        builder.append("Agilidade: ");
        builder.append(getAgilidade());
        builder.append("\n");

        return builder.toString();
    }

}
