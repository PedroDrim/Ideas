/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package battleroyalle.model;

/**
 *
 * @author alunoinf
 */
public interface Participante {
    public String getNome();
    public int getLevel();
    public double getVidaMaxima();
    public double getVidaAtual();
    public double getForca();
    public double getDefesa();
    public double getAgilidade();
    public void dropVida(double vida);
    public void levelUp();
}
