/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package battleroyalle.view;

import battleroyalle.controler.Generator;
import battleroyalle.model.Fighter;

/**
 *
 * @author alunoinf
 */
public class Inicio {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Fighter p1 = Generator.getInstance().createFighter();
        Fighter p2 = Generator.getInstance().createFighter();
        Arena arena = new Arena(p1,p2);
        arena.start();
    }
    
}
