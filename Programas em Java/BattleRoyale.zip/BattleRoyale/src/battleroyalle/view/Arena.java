/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package battleroyalle.view;

import battleroyalle.controler.ErrorsControl;
import battleroyalle.model.Fighter;

/**
 *
 * @author alunoinf
 */
public class Arena extends ErrorsControl {

    private Fighter participante1;
    private Fighter participante2;

    public Arena(Fighter participante1, Fighter participante2) {
        this.participante1 = participante1;
        this.participante2 = participante2;
    }

    public void start() {
        System.out.println("Inicinado batalha.\n");
        do {
            turno(participante1, participante2);
            System.out.println();
            turno(participante2, participante1);
            System.out.println();
        } while (true);
    }

    private void turno(Fighter jogador, Fighter oponente) {
        do {
            System.out.println("Turno do jogador: " + jogador.getNome());
            System.out.println("(1) Atacar.");
            System.out.println("(2) Defender.");
            System.out.println("(3) Desviar.");
            System.out.println("(4) Exibir status do oponente.");
            System.out.print("Opção: ");

            int opcao = getInt();
            System.out.println();

            switch (opcao) {
                case 1:
                    System.out.println(jogador.getNome() + " ataca " + oponente.getNome() + ".");
                    jogador.atacar(oponente);
                    return;

                case 2:
                    System.out.println(jogador.getNome() + " inicia defesa.");
                    jogador.defender();
                    return;

                case 3:
                    System.out.println(jogador.getNome() + " se prepara para desviar.");
                    jogador.desviar();
                    return;

                case 4:
                    System.out.println("Exibindo status do oponente.");
                    System.out.println(oponente.getStatus());
                    break;

                default:
                    System.out.println("Opção desconhecida.");
            }
        } while (true);

    }

}
