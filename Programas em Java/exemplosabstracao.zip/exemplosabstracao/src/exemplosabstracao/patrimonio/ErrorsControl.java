/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exemplosabstracao.patrimonio;

import java.util.Scanner;

/**
 *
 * @author alunoinf
 */
public abstract class ErrorsControl {

    private static Scanner scan = new Scanner(System.in);

    public static int getErrorsInt() {
        int retorno = 0;

        boolean ciclo = true;
        do {
            try {
                String resp = scan.nextLine();
                retorno = Integer.parseInt(resp);
                ciclo = false;
            } catch (ObjetosException run) {
                throw new ObjetosException("Insira um número inteiro.");
            }
        } while (ciclo);

        return retorno;
    }

    public static long getErrorsLong() {
        long retorno = 0;

        boolean ciclo = true;
        do {
            try {
                String resp = scan.nextLine();
                retorno = Long.parseLong(resp);
                ciclo = false;
            } catch (RuntimeException run) {
                throw new ObjetosException("Insira um número long.");
            }
        } while (ciclo);

        return retorno;
    }

    public static String getErrosString() {
        String resposta = null;

        boolean ciclo = true;
        do {
            try {
                resposta = scan.nextLine();
                if (resposta.equals("")) {
                    System.err.println("Este campo não pode ser vazio.");
                } else {
                    ciclo = false;
                }
            } catch (RuntimeException run) {
                throw new ObjetosException("Insira uma String.");
            }
        } while (ciclo);

        return resposta;
    }
}
