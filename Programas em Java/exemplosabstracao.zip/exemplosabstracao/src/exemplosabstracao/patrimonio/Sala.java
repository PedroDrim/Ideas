/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exemplosabstracao.patrimonio;

/**
 *
 * @author marceloquinta
 */
public class Sala {
    
    private int numero;
    private Departamento departamento;

    public Sala(int numero, Departamento departamento) {
        this.numero = numero;
        this.departamento = departamento;
    }

    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public Departamento getDepartamento() {
        return departamento;
    }

    public void setDepartamento(Departamento departamento) {
        this.departamento = departamento;
    }
    
    
}
