/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exemplosabstracao.patrimonio;

/**
 *
 * @author marceloquinta
 */
public class Objeto {
  
    private long identificador;
    private String nome;
    private String descricao;
    private Sala sala;

    public Objeto(long identificador, String nome, String descricao) {
        setIdentificador(identificador);
        setNome(nome);
        setDescricao(descricao);
    }

    public long getIdentificador() {
        return identificador;
    }

    public void setIdentificador(long identificador) {
        this.identificador = identificador;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        if(nome != null){
            this.nome = nome;
        }
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public Sala getSala() {
        return sala;
    }

    public void setSala(Sala sala) {
        this.sala = sala;
    }
    
    @Override
    public String toString(){
        StringBuilder builder = new StringBuilder();
        builder.append("ID: ");
        builder.append(getIdentificador());
        builder.append("\n");
        
        builder.append("NOME: ");
        builder.append(getNome());
        builder.append("\n");
        
        builder.append("DESCRIÇÂO: ");
        builder.append(getDescricao());
        builder.append("\n");
        
        return builder.toString();
    }
}
