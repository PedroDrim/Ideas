/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exemplosabstracao.patrimonio;

/**
 *
 * @author marceloquinta
 */
public class Main extends ErrorsControl{

    static GestorDeObjetos gestor = new GestorDeObjetos();

    public static void main(String args[]) {
        System.out.println("");
        int opcao = 0;
        final int SAIR = 5;
        do {
            System.out.println("Entre com a opção desejada");
            System.out.println("1 - ADICIONAR OBJETO");
            System.out.println("2 - REMOVER OBJETO");
            System.out.println("3 - PROCURAR OBJETO");
            System.out.println("4 - IMPRIMIR OBJETOS");
            System.out.println("5 - SAIR");
            System.out.print("Opção: ");

            opcao = getErrorsInt();

            switch (opcao) {
                case 1:
                    adicionarObjeto();
                    System.out.println("");
                    break;
                case 2:
                    removerObjeto();
                    System.out.println("");
                    break;
                case 3:
                    procurarObjeto();
                    System.out.println("");
                    break;
                case 4:
                    imprimirObjetos();
                    System.out.println("");
                    break;
                case SAIR:
                    System.out.println("MUITO OBRIGADO!");
                    break;
                default:
                    System.out.println("ENTRADA INVÁLIDA\n");
            }
        } while (opcao != SAIR);
        System.out.println("FIM DO PROGRAMA");
    }

    public static void adicionarObjeto() {
        System.out.print("Entre com o identificador: ");
        long id = getErrorsLong();
        System.out.print("Entre com o nome: ");
        String nome = getErrosString();
        System.out.print("Entre com a descrição: ");
        String descricao = getErrosString();

        Objeto objeto = new Objeto(id, nome, descricao);
        gestor.add(objeto);

    }

    public static void procurarObjeto() {
        System.out.print("Entre com o identificador do patrimonio: ");
        long id = getErrorsLong();

        if (gestor.existe(id)) {
            Objeto objeto = gestor.getObjetoById(id);

            imprimirObjetoUnico(objeto);

        } else {
            System.out.print("Patrimônio não encontrado.");
        }
    }

    public static void removerObjeto() {
        System.out.print("Entre com o identificador do patrimonio: ");
        long id = getErrorsLong();

        if (gestor.existe(id)) {
            gestor.remove(id);
            System.out.println("Patrimônio removido com sucesso");
        } else {
            System.out.println("Patrimônio não encontrado.");
        }
    }

    public static void imprimirObjetos() {
        System.out.println("----");
        for (Objeto objeto : gestor.getObjetos()) {
            if (objeto != null) { 
                imprimirObjetoUnico(objeto);
                System.out.println("----");
            }

        }
    }
    
    private static void imprimirObjetoUnico(Objeto objeto){
        System.out.print(objeto.toString());
    }

}
