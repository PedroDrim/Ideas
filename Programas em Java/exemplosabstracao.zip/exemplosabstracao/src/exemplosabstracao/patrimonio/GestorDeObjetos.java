/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exemplosabstracao.patrimonio;

/**
 *
 * @author marceloquinta
 */
public class GestorDeObjetos {

    private Objeto[] objetos;

    public GestorDeObjetos() {
        objetos = new Objeto[2];
    }

    public void add(Objeto objeto) throws ObjetosException{
        if (!existe(objeto.getIdentificador())) {
            //tenta adicionar em uma posicao livre
            for (int i = 0; i < objetos.length; i++) {
                if (objetos[i] == null) {
                    objetos[i] = objeto;
                    return;
                }
            }
        }
        throw new ObjetosException("Não foi possivel registrar o partimônio.");
    }

    public void remove(long id) throws ObjetosException{
        //Existe um erro o patrimonio quando é atribuido o valor null ele permanece inalterado depois do for.
        int contador = 0;
        for (Objeto patrimonio : objetos) {
            if (patrimonio != null) {
                if (patrimonio.getIdentificador() == id) {
                    objetos[contador] = null;
                    return;
                }
                contador++;
            }
        }
        throw new ObjetosException("Patrimônio não foi registrado.");

    }

    public Objeto getObjetoById(long id) {
        for (Objeto patrimonio : objetos) {
            if (patrimonio != null) {
                if (patrimonio.getIdentificador() == id) {
                    return patrimonio;
                }
            }
        }
        throw new ObjetosException("Não existe patrimônio com essa identificação.");
    }

    public boolean existe(long id) {
        for (Objeto patrimonio : objetos) {
            if (patrimonio != null) {
                if (patrimonio.getIdentificador() == id) {
                    return true;
                }
            }
        }
        return false;
    }

    public Objeto[] getObjetos() {
        return this.objetos;
    }

}
